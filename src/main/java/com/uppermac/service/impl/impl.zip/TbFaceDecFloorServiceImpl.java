package com.uppermac.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSONObject;
import com.uppermac.entity.TbFaceDecFloor;
import com.uppermac.repository.TbFaceDecFloorRepository;
import com.uppermac.service.TbFaceDecFloorService;
import com.uppermac.utils.MyLog;
import com.uppermac.utils.RedisUtils;


@Service
public class TbFaceDecFloorServiceImpl implements TbFaceDecFloorService{
	
	
	@Resource
	private RedisUtils redisUtils = new RedisUtils();
	
	@Autowired
	private TbFaceDecFloorRepository tbFaceDecFloorRepository;

	@Override
	public List<TbFaceDecFloor> findDecIP(String floor) {
		
	/*	List<TbFaceDecFloor> list=null;				//返回对象
		String key = "key_faceDecFloorlist_"+floor;	//redis key
		String faceDecFloorlist = null;				//redis value
		
		try {
			faceDecFloorlist = redisUtils.get(key);
			if(faceDecFloorlist == null || StringUtils.isEmpty(faceDecFloorlist)) {
				
				list = tbFaceDecFloorRepository.findDecIP(floor);
				redisUtils.set(key, JSONObject.toJSONString(list));
			}else {
				list = JSONObject.parseArray(faceDecFloorlist,TbFaceDecFloor.class);
			}
		}catch (Exception e) {
			
		}finally {
			return list;
		}
		*/
		return tbFaceDecFloorRepository.findDecIP(floor);
		
	}

	@SuppressWarnings("finally")
	@Override
	public List<TbFaceDecFloor> findAll() {
	/*	List<TbFaceDecFloor> list=null;				//返回对象
		String key = "key_faceDecFloorlist_all";	//redis key
		String faceDecFloorlist = null;				//redis value
		
		try {
			faceDecFloorlist = redisUtils.get(key);
			if(faceDecFloorlist == null || StringUtils.isEmpty(faceDecFloorlist)) {
				
				list = tbFaceDecFloorRepository.findAll();
				redisUtils.set(key, JSONObject.toJSONString(list));
			}else {
				list = JSONObject.parseArray(faceDecFloorlist,TbFaceDecFloor.class);
			}
		}catch (Exception e) {
			
		}finally {
			return list;
		}
		*/
		return tbFaceDecFloorRepository.findAll();
	}

	/*
	 * 通过楼层找所有人脸设备IP
	 * 
	 */
	@Override
	public List<String> getAllFaceDeviceIP(String companyFloor) {
		// TODO Auto-generated method stub
		List<String> allFaceIP = new ArrayList<String>();
		if (StringUtils.isEmpty(companyFloor)) {
			List<TbFaceDecFloor> list = tbFaceDecFloorRepository.findAll();
			if (list.size() > 0) {
				for (int i = 0; i < list.size(); i++) {
					String faceIp = ((TbFaceDecFloor) list.get(i)).getFaceip();
					allFaceIP.add(faceIp);
				}
			}
			
		} else {
			if (companyFloor.contains("|")) {
				String[] floors = companyFloor.split("\\|");
				for (String floor : floors) {
					List<TbFaceDecFloor> list = tbFaceDecFloorRepository.findDecIP(floor);
					if (list.size() > 0) {
						for (int i = 0; i < list.size(); i++) {
							String faceIp = ((TbFaceDecFloor) list.get(i)).getFaceip();
							// 排查重复 当设备包含大楼N次时，只取一次
							if (!allFaceIP.contains(faceIp)) {
								allFaceIP.add(faceIp);
							}
						}
					}
				}

			} else {
				List<TbFaceDecFloor> list = tbFaceDecFloorRepository.findDecIP(companyFloor);
				if (list.size() > 0) {
					for (int i = 0; i < list.size(); i++) {
						String faceIp = ((TbFaceDecFloor) list.get(i)).getFaceip();
						allFaceIP.add(faceIp);
					}
				}
			}
		}
		return allFaceIP;
	}
	
}
