package com.uppermac.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSONObject;
import com.uppermac.entity.TbDevice;
import com.uppermac.repository.TbDeviceRepository;
import com.uppermac.service.TbDeviceService;
import com.uppermac.utils.RedisUtils;

@SuppressWarnings("finally")
@Service
public class TbDeviceServiceImpl implements TbDeviceService{

	@Resource
	private RedisUtils redisUtils;
	
	@Autowired
	private TbDeviceRepository tbDeviceRepository;
	
	static Logger logger = LogManager.getLogger(TbDeviceServiceImpl.class);
	
	@Override
	public List<TbDevice> findAll() {
		List<TbDevice> list=null;			//返回对象
		String key = "device_all";		//redis key
		String devicelist = null;			//redis value
		
		try {
			devicelist = redisUtils.get(key);
			if(devicelist == null || StringUtils.isEmpty(devicelist)) {
				
				list = tbDeviceRepository.findAll();
				redisUtils.set(key, JSONObject.toJSONString(list));
			}else {
				list = JSONObject.parseArray(devicelist,TbDevice.class);
			}
		}catch (Exception e) {
			
		}finally {
			return list;
		}
	}
	
	@Override
	public TbDevice findOne(String id) {
		TbDevice device = null;
		String key = "device_"+id;
		String deviceValue = null;
		
		try {
			deviceValue = redisUtils.get(key);
			if(deviceValue == null || StringUtils.isEmpty(deviceValue)) {
				
				device = tbDeviceRepository.findByDeviceId(id);
				System.out.println(device.toString());
				redisUtils.set(key, JSONObject.toJSONString(device));
			}else {
				device = JSONObject.parseObject(deviceValue,TbDevice.class);
			}
		}catch (Exception e) {
			
		}finally {
			return device;
		}	
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub
		String key = "device_"+id;
		boolean result = redisUtils.delete(key);
		if(result == true) {
			logger.info("redis删除"+key+"成功");
		}else {
			logger.error("redis删除"+key+"失败");
		}
		tbDeviceRepository.deleteById(id);
	}

	@Override
	public void save(TbDevice tbDevice) {
		// TODO Auto-generated method stub
		tbDeviceRepository.save(tbDevice);
	}

	@Override
	public void update(TbDevice tbDevice) {
		// TODO Auto-generated method stub
		tbDeviceRepository.save(tbDevice);
	}

	@Override
	public List<TbDevice> findByOrgcode(String orgcode) {
		List<TbDevice> list=null;			//返回对象
		String key = "device_"+orgcode;		//redis key
		String devicelist = null;			//redis value
		
		try {
			devicelist = redisUtils.get(key);
			if(devicelist == null || StringUtils.isEmpty(devicelist)) {
				
				list = tbDeviceRepository.findByOrgcode(orgcode);
				redisUtils.set(key, JSONObject.toJSONString(list));
			}else {
				list = JSONObject.parseArray(devicelist,TbDevice.class);
			}
		}catch (Exception e) {
			
		}finally {
			return list;
		}
	
	}

	@Override
	public TbDevice findOUTByReaderIp(String readerIp) {
		TbDevice device = null;
		String key = "readerIp_"+readerIp;
		String deviceValue = null;
		
		try {
			deviceValue = redisUtils.get(key);
			if(deviceValue == null || StringUtils.isEmpty(deviceValue)) {
				
				device = tbDeviceRepository.findOUTByReaderIp(readerIp).get(0);
				redisUtils.set(key, JSONObject.toJSONString(device));
			}else {
				device = JSONObject.parseObject(deviceValue,TbDevice.class);
			}
		}catch (Exception e) {
			
		}finally {
			return device;
		}
	}

	@Override
	public TbDevice findOUTByfaceRecogIp(String faceRecogIp) {
		TbDevice device = null;
		String key = "faceRecogIp_"+faceRecogIp;
		String deviceValue = null;
		
		try {
			deviceValue = redisUtils.get(key);
			if(deviceValue == null || StringUtils.isEmpty(deviceValue)) {
				if(tbDeviceRepository.findOUTByfaceRecogIp(faceRecogIp).size()<=0) {
					return null;
				}
				device = tbDeviceRepository.findOUTByfaceRecogIp(faceRecogIp).get(0);
				redisUtils.set(key, JSONObject.toJSONString(device));
			}else {
				device = JSONObject.parseObject(deviceValue,TbDevice.class);
			}
		}catch (Exception e) {
			
		}finally {
			return device;
		}
		
	}

}
