package com.uppermac.service;

import java.util.List;

import com.uppermac.entity.TbDevice;
import com.uppermac.entity.TbFaceDecFloor;

public interface TbFaceDecFloorService {
	
	
	List<TbFaceDecFloor> findDecIP(String floor);
	
	List<TbFaceDecFloor> findAll();
	
	List<String> getAllFaceDeviceIP(String companyFloor);
}
