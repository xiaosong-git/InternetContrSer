package com.uppermac.service;

import java.util.List;

import com.uppermac.entity.TbDevice;

public interface TbDeviceService {

	List<TbDevice> findAll();
	
	TbDevice findOne(String id); 
	
	void delete(String id);
	
	void save(TbDevice tbDevice);
	
	void update(TbDevice tbDevice);
	
	List<TbDevice> findByOrgcode(String orgcode);
	
	TbDevice findOUTByReaderIp(String readerIp);
	
	TbDevice findOUTByfaceRecogIp(String faceRecogIp);
}
